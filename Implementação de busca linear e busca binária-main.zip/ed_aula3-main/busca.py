# Lucas De Lima Almeida / 185964
# Olivia Sampaio Prestes / 184426
# Matheus Henrique Santos Pereira / 179394 
# Rhyan Yassin Freitas Ahmad / 190485
#-----------------------------------------------------------------------------------------------------------#
import os
import platform

# Função de busca linear
def busca_linear(lista, alvo):
    """Realiza uma busca linear em uma lista ordenada."""
    for i, elemento in enumerate(lista):
        if elemento == alvo:
            return i
        if elemento > alvo:
            break
    return -1

# Função de busca binária
def busca_binaria(lista, alvo):
    """Realiza uma busca binária em uma lista ordenada."""
    esquerda, direita = 0, len(lista) - 1
    while esquerda <= direita:
        meio = (esquerda + direita) // 2
        if lista[meio] == alvo:
            return meio
        elif lista[meio] < alvo:
            esquerda = meio + 1
        else:
            direita = meio - 1
    return -1

# Função para obter uma lista ordenada do usuário
def obter_lista_usuario():
    """Obtém uma lista de números ordenados do usuário."""
    while True:
        try:
            lista = []
            while True:
                num = input("Digite um número (ou 'x' para parar): ")
                if num.lower() == 'x':
                    break
                lista.append(int(num))
            if lista != sorted(lista):
                print("A lista inserida não está ordenada. Tente novamente.")
                continue
            if len(lista) != len(set(lista)):
                print("A lista inserida não pode conter números duplicados. Tente novamente.")
                continue
            return lista
        except ValueError:
            print("Entrada inválida. Certifique-se de inserir números válidos.")

# Função para criar uma lista de números
def criar_lista_numeros(par=True, limite_superior=100):
    """Cria uma lista de números pares ou ímpares até um limite superior."""
    numeros = [x for x in range(2, limite_superior + 1) if x % 2 == 0] if par else [x for x in range(1, limite_superior + 1) if x % 2 == 1]
    return numeros

# Função para limpar o console
def limpar_console():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def main():
    limpar_console()
    
    OPCAO_SAIR = 3
    OPCOES_VALIDAS = [1, 2, OPCAO_SAIR]

    while True:
        print("Opções:")
        print("1 - Busca Linear")
        print("2 - Busca Binária")
        print(f"{OPCAO_SAIR} - Sair")

        try:
            opcao = int(input("Escolha uma opção: "))
        except ValueError:
            print("Opção inválida. Por favor, digite um número.")
            continue
        
        if opcao == OPCAO_SAIR:
            limpar_console()
            print("Encerrando o programa.")
            break
        
        if opcao not in OPCOES_VALIDAS:
            print(f"Opção inválida. Escolha entre {', '.join(map(str, OPCOES_VALIDAS))}.")
            continue

        while True:
            print("\nOpções de lista:")
            print("1 - Lista de números ímpares")
            print("2 - Lista de números pares")
            print("3 - Digitar lista de números ordenados")

            try:
                opcao_lista = int(input("Escolha uma opção de lista: "))
                if opcao_lista in [1, 2, 3]:
                    break
                else:
                    print("Opção inválida. Escolha entre 1, 2, 3.")
            except ValueError:
                print("Opção inválida. Por favor, digite um número.")
                continue

        if opcao_lista == 1:
            lista = criar_lista_numeros(par=False)
        elif opcao_lista == 2:
            lista = criar_lista_numeros(par=True)
        elif opcao_lista == 3:
            lista = obter_lista_usuario()

        if not lista:
            continue

        try:
            alvo = int(input("Digite o numero que você deseja encontrar:\n"))
        except ValueError:
            print("Entrada invalida. Certifique-se de inserir um número valido.")
            continue

        if opcao == 1:
            resultado = busca_linear(lista, alvo)
        elif opcao == 2:
            resultado = busca_binaria(lista, alvo)

        if resultado != -1:
            busca_tipo = "linear" if opcao == 1 else "binária"
            print(f"O elemento {alvo} foi encontrado na busca {busca_tipo} no índice {resultado}.")
        else:
            print(f"O elemento {alvo} não foi encontrado na lista.")

        input("Pressione Enter para continuar...")
        limpar_console()

if __name__ == "__main__":
    main()
