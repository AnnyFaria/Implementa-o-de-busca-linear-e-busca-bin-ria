# Programa de Busca Linear e Busca Binária

# Funcionalidades

- Busca linear em uma lista ordenada.
- Busca binária em uma lista ordenada.
- Geração de listas de números pares ou ímpares até um limite superior.
- Entrada de uma lista ordenada de numeros pelo usuario.
- Interface de usuário simples e interativa.

## Bibliotecas Utilizadas

O programa utiliza as seguintes bibliotecas Python:

- `os`: Usada para limpar o console após cada busca.
- `platform`: Usada para verificar o sistema operacional e executar o comando apropriado para limpar o console.

## Como Usar

1. Certifique-se de ter o Python instalado em seu sistema.
2. Baixe ou clone este repositório.
3. Abra um terminal na pasta onde o arquivo `busca.py` está localizado.
4. Execute o comando `python busca.py` para iniciar o programa.
5. Siga as instruções no console para escolher o tipo de busca e o tipo de lista.

## Exemplo de Uso

```shell
$ python busca.py

Opções:
1 - Busca Linear
2 - Busca Binária
3 - Sair
Escolha uma opção: 1

Opções de lista:
1 - Lista de números ímpares
2 - Lista de números pares
3 - Digitar lista de números ordenados
Escolha uma opção de lista: 1

Digite o número que você deseja encontrar:
4
O elemento 4 não foi encontrado na lista.
Pressione Enter para continuar...
